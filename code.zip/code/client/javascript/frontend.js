const premiersBtn = document.getElementById("premiersBtn");
const profileBtn = document.getElementById("profileBtn");
const createBtn = document.getElementById("createBtn");
const searchBtn = document.getElementById("searchBtn");

imgInp.onchange = (evt) => {
  const [file] = imgInp.files;
  if (file) {
    blah.src = URL.createObjectURL(file);
  }
};

premiersBtn.addEventListener("click", () => {
  profileBtn.classList.remove("active");
  createBtn.classList.remove("active");
  premiersBtn.classList.add("active");
  searchBtn.classList.remove("active");
});

profileBtn.addEventListener("click", () => {
  premiersBtn.classList.remove("active");
  createBtn.classList.remove("active");
  profileBtn.classList.add("active");
  searchBtn.classList.remove("active");
});

createBtn.addEventListener("click", () => {
  premiersBtn.classList.remove("active");
  profileBtn.classList.remove("active");
  createBtn.classList.add("active");
  searchBtn.classList.remove("active");
});

searchBtn.addEventListener("click", () => {
  premiersBtn.classList.remove("active");
  profileBtn.classList.remove("active");
  createBtn.classList.remove("active");
  searchBtn.classList.add("active");
});

// Get the login and account pages
const loginPage = document.getElementById("login_page");
const accPage = document.getElementById("accPage");

// Hide the login and account pages
loginPage.style.display = "block";
accPage.style.display = "none";

// Get the login form
const loginForm = document.querySelector(".login_page .account_form");

const mainPage = document.getElementById("main_page");
const profilePage = document.getElementById("profile_page");
const createPage = document.getElementById("create_page");
const searchPage = document.getElementById("search_page");
const nav = document.getElementById("Navbar");

nav.style.display = "none";
mainPage.style.display = "none";
profilePage.style.display = "none";
createPage.style.display = "none";
searchPage.style.display = "none";

premiersBtn.addEventListener("click", () => {
  mainPage.style.display = "block";
  profilePage.style.display = "none";
  createPage.style.display = "none";
  searchPage.style.display = "none";
});

profileBtn.addEventListener("click", () => {
  mainPage.style.display = "none";
  profilePage.style.display = "block";
  createPage.style.display = "none";
  searchPage.style.display = "none";
});

createBtn.addEventListener("click", () => {
  mainPage.style.display = "none";
  profilePage.style.display = "none";
  createPage.style.display = "block";
  searchPage.style.display = "none";
});

searchBtn.addEventListener("click", () => {
  mainPage.style.display = "none";
  profilePage.style.display = "none";
  createPage.style.display = "none";
  searchPage.style.display = "block";
});

const signUpLink = document.querySelector(".here");
signUpLink.addEventListener("click", () => {
  loginPage.style.display = "none";
  accPage.style.display = "block";
});

const loginLink = document.querySelector(".sign_up .here");
loginLink.addEventListener("click", () => {
  loginPage.style.display = "block";
  accPage.style.display = "none";
});


document
  .querySelector(".item-3 .material-icons")
  .addEventListener("click", function () {
    // Navigate to the login page
    loginPage.style.display = "block";
    accPage.style.display = "none";
    nav.style.display = "none";
    mainPage.style.display = "none";
    profilePage.style.display = "none";
    createPage.style.display = "none";
    searchPage.style.display = "none";

    // Reset any form inputs if needed
    document.querySelector(".account_form").reset();
  });

document.getElementById("image_upload").addEventListener("change", function () {
  const file = this.files[0];
  const reader = new FileReader();

  reader.onload = function (e) {
    document.getElementById("preview_image").src = e.target.result;
  };

  reader.readAsDataURL(file);
});

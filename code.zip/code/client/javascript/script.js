//function to format the front end form to register a users
async function addUser(event) {
  event.preventDefault();
  const firstName = document.getElementById("firstName").value;
  const age = document.getElementById("age").value;
  const lastName = document.getElementById("lastName").value;
  const password = document.getElementById("password").value;
  const retypePassword = document.getElementById("retypePassword").value;
  const email = document.getElementById("email").value;
  const username = document.getElementById("username").value;

  const mainPage = document.getElementById("main_page");
  const profilePage = document.getElementById("profile_page");
  const createPage = document.getElementById("create_page");
  const nav = document.getElementById("Navbar");
  const accPage = document.getElementById("accPage");
  const login_page = document.getElementById("login_page");
  const followers = [];
  const following = [];
  const posts = 0;

  var feedback = document.getElementById("feedback");

  // Create a new FormData object
  const formData = new FormData();

  feedback.innerText = ""; // Clear previous error messages
  // Check if the passwords match
  if (password !== retypePassword) {
    feedback.innerText = "Passwords do not match!";
    return; // Stop further execution
  }

  // Check email format
  var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    feedback.innerText = "Invalid email format";
    return false; // Prevent form submission
  }
  const fileInput = document.querySelector('input[name="profileImage"]');
  // Append the selected file to the FormData object
  formData.append("myFile", fileInput.files[0]);
  formData.append("username", username);
  formData.append("firstName", firstName);
  formData.append("lastName", lastName);
  formData.append("age", age);
  formData.append("password", password);
  formData.append("retypePassword", retypePassword);
  formData.append("email", email);
  formData.append("profileImage", fileInput.files[0]);
  formData.append("followers", followers);
  formData.append("following", following);
  formData.append("posts", posts);

  try {
    const response = await fetch("http://localhost:8080/m00909449/ticket", {
      method: "POST",
      body: formData,
    });

    //Output result
    const result = await response.json();
    console.log("User inserted successfully!");
    console.log(result);

    accPage.style.display = "none";
    login_page.style.display = "block";
    nav.style.display = "none";
    mainPage.style.display = "none";
    profilePage.style.display = "none";
    createPage.style.display = "none";
  } catch (err) {
    console.log("Error adding user: " + err);
  }
}

//function to format the front end login form to login a user
async function userLogin() {
  const username = document.getElementById("login_username").value;
  const password = document.getElementById("login_password").value;

  const mainPage = document.getElementById("main_page");
  const profilePage = document.getElementById("profile_page");
  const createPage = document.getElementById("create_page");
  const nav = document.getElementById("Navbar");
  const loginPage = document.getElementById("login_page");
  const warn = document.getElementById("feedback02");
  const toast = document.getElementById("toast");

  try {
    const response = await fetch("http://localhost:8080/m00909449/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ username, password }),
    });
    const data = await response.json();
    if (data.login) {
      // Show the "Premiers Page"
      nav.style.display = "block";
      mainPage.style.display = "block";
      loginPage.style.display = "none";
      profilePage.style.display = "none";
      createPage.style.display = "none";
      updateNavbar();
      fillMain();
      // Show toast notification
      toast.innerText = `Welcome ${username}`;
      toast.classList.add("show-toast");
      setTimeout(() => {
        toast.classList.remove("show-toast");
      }, 3000);
    } else {
      console.error("Login failed:", data.message);
      warn.innerText = "Username or Password incorrect";
    }
  } catch (error) {
    console.error("Error:", error);
  }
}

//function to log a user out
async function userLogout() {
  try {
    const response = await fetch("http://localhost:8080/m00909449/logout", {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    });
    const data = await response.json();
    console.log(data); // Handle response from server
  } catch (error) {
    console.error("Error:", error);
  }
}

//gets all the users and then filters through them based on the search
// bar input
async function getUsers() {
  try {
    const response = await fetch("http://localhost:8080/m00909449/users");
    if (!response.ok) {
      throw new Error("Failed to fetch users");
    }
    const usersArray = await response.json();
    const searchQuery = document.querySelector("input[name=search]").value;
    const filteredUsers = usersArray.filter((user) => {
      return user.username.includes(searchQuery);
    });

    const searchedUserContainer = document.getElementById(
      "searched_user_container"
    );
    searchedUserContainer.innerHTML = "";

    filteredUsers.forEach((searchedUser) => {
      const userDiv = document.createElement("div");
      userDiv.classList.add("searched_user");
      userDiv.addEventListener("click", () => {
        openUserProfile(searchedUser);
      });

      const imageDiv = document.createElement("div");
      imageDiv.classList.add("searched_user_image");
      const image = document.createElement("img");
      image.src = searchedUser.profileImageUrl;
      imageDiv.appendChild(image);

      const detailsDiv = document.createElement("div");
      detailsDiv.classList.add("searched_user_details");
      const usernameDiv = document.createElement("div");
      usernameDiv.classList.add("searched_username");
      usernameDiv.textContent = searchedUser.username;
      const followingDiv = document.createElement("div");
      followingDiv.classList.add("following");
      followingDiv.innerHTML = `
        <p>${searchedUser.posts} posts</p>
        <p>${searchedUser.followers.length} followers</p>
        <p>${searchedUser.following.length} following</p>
      `;
      detailsDiv.appendChild(usernameDiv);
      detailsDiv.appendChild(followingDiv);

      userDiv.appendChild(imageDiv);
      userDiv.appendChild(detailsDiv);

      searchedUserContainer.appendChild(userDiv);
    });
  } catch (error) {
    console.error("Error fetching users:", error);
    // Handle error
  }
}

//whenever we click a user's profile this part come's up
async function openUserProfile(searchedUser) {
  try {
    document.getElementById("search_page").style.display = "none";
    document.getElementById("profile_page").style.display = "block";
    document.getElementById("editProfileButton").style.display = "none";
    document.getElementById("followProfileButton").style.display = "block";
    //this next line is to ensure that the add follower function gets the searchd user
    document.getElementById("followProfileButton").onclick = async () => {
      await addFollower(searchedUser._id, searchedUser.username);
    };

    document.getElementById("profilepageprofileimage").src =
      searchedUser.profileImageUrl;
    document.getElementById("Profile_Page_Username").textContent =
      searchedUser.username;
    document.getElementById("profile_first_name").textContent =
      searchedUser.firstName;
    document.getElementById("profile_last_name").textContent =
      searchedUser.lastName;
    document.getElementById("profile_posts").textContent =
      searchedUser.posts + " posts";
    document.getElementById("profile_followers").textContent =
      searchedUser.followers.length + " followers";
    document.getElementById("profile_following").textContent =
      searchedUser.following.length + " following";
  } catch (error) {
    console.error("Error updating current user profile:", error);
  }
  getPostsOfUser(`posts/${searchedUser._id}`);
}

//format the front end form to send the server the post details
async function addPost(event) {
  event.preventDefault();
  const title = document.getElementById("input_post").value;
  const description = document.getElementById("description").value;
  const imageFile = document.getElementById("image_upload").files[0];

  // Create a FormData object to store the data
  const formData = new FormData();
  formData.append("title", title);
  formData.append("description", description);
  formData.append("imageFile", imageFile);

  // Return the FormData object

  try {
    const response = await fetch("http://localhost:8080/m00909449/post", {
      method: "POST",
      body: formData,
    });

    // Output result
    const result = await response.json();
    console.log("Post added successfully!");
    console.log(result);

    // Reset the form
    document.getElementById("input_post").value = "";
    document.getElementById("description").value = "";
    document.getElementById("image_upload").value = "";
  } catch (err) {
    console.log("Error adding post: " + err);
  }
}

//this will fill the profile page according to the current logged in user
async function updateCurrentUserProfile() {
  try {
    const response = await fetch("http://localhost:8080/m00909449/currentUser");
    const user = await response.json();

    document.getElementById("profilepageprofileimage").src =
      user.profileImageUrl;
    document.getElementById("Profile_Page_Username").textContent =
      user.username;
    document.getElementById("profile_first_name").textContent = user.firstName;
    document.getElementById("profile_last_name").textContent = user.lastName;
    document.getElementById("profile_posts").textContent =
      user.posts + " posts";
    document.getElementById("profile_followers").textContent =
      user.followers.length + " followers";
    document.getElementById("profile_following").textContent =
      user.following.length + " following";

    const followProfileButton = document.getElementById("followProfileButton");
    document.getElementById("editProfileButton").style.display = "block";
    followProfileButton.style.display = "none";
  } catch (error) {
    console.error("Error updating current user profile:", error);
  }
  getPostsOfUser("myPosts");
}

//the user information gets updated in the navbar
async function updateNavbar() {
  try {
    const response = await fetch("/m00909449/currentUser");
    const currentUser = await response.json();

    // Update profile image
    document.getElementById("navabr_image").src = currentUser.profileImageUrl;

    // Update username
    document.getElementById("loggedInUsername").textContent =
      currentUser.username;
  } catch (error) {
    console.error("Error updating navbar:", error);
  }
}

//this will get the posts of the users based on the route
async function getPostsOfUser(route) {
  try {
    const response = await fetch(`/m00909449/${route}`);
    const myPosts = await response.json();

    const profilePostsDiv = document.getElementById("profile_posts_section");

    // Clear existing posts
    profilePostsDiv.innerHTML = "";

    // Iterate over each post and create HTML elements
    myPosts.forEach((post) => {
      const postDiv = document.createElement("div");
      postDiv.classList.add("post");

      const title = document.createElement("h3");
      title.textContent = post.title;
      title.id = "profile_post_id";

      const image = document.createElement("img");
      image.src = post.imageUrl;
      image.alt = "";
      image.id = "profile_post_image";

      postDiv.appendChild(title);
      postDiv.appendChild(image);

      profilePostsDiv.appendChild(postDiv);
    });
  } catch (error) {
    console.error("Error fetching user's posts");
  }
}

//this will take the id of the searched user from the getUsers function to then add them into their following
async function addFollower(followID, followUsername) {
  try {
    const response = await fetch("http://localhost:8080/m00909449/follow", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ followID, followUsername }),
    });
    console.log(followID);

    if (!response.ok) {
      throw new Error("Failed to add follower");
    }
  } catch (error) {
    console.error("Error adding follower:", error);
  }
}

//function to fill the main page
function fillMain() {
  fetch("/m00909449/posts/following")
    .then((response) => response.json())
    .then((posts) => {
      const allPostsContainer = document.querySelector(".all_posts");
      allPostsContainer.innerHTML = "";

      posts.forEach((post) => {
        const feedPost = document.createElement("div");
        feedPost.classList.add("feed_post");
        feedPost.dataset.postId = post._id;
        feedPost.dataset.title = post.title;
        feedPost.dataset.imageUrl = post.imageUrl;
        feedPost.dataset.description = post.description;
        feedPost.dataset.likes = post.likes;
        feedPost.dataset.owner = post.owner;

        const postTop = document.createElement("div");
        postTop.classList.add("post_top");

        const title = document.createElement("i");
        title.textContent = post.title;

        postTop.appendChild(title);

        const movieImage = document.createElement("img");
        movieImage.src = post.imageUrl;
        movieImage.classList.add("movie_post_images");

        const postBottom = document.createElement("div");
        postBottom.classList.add("post_bottom");

        const heartIcon = document.createElement("i");
        heartIcon.classList.add("fas", "fa-heart", "h");

        const likeCount = document.createElement("i");
        likeCount.textContent = post.likes;
        likeCount.classList.add("likeCounts");

        const paperPlaneIcon = document.createElement("i");
        paperPlaneIcon.classList.add("fas", "fa-comments", "s");

        postBottom.appendChild(heartIcon);
        postBottom.appendChild(paperPlaneIcon);
        postBottom.appendChild(likeCount);

        feedPost.appendChild(postTop);
        feedPost.appendChild(movieImage);
        feedPost.appendChild(postBottom);

        allPostsContainer.appendChild(feedPost);
      });

      allPostsContainer.addEventListener("click", (event) => {
        const feedPost = event.target.closest(".feed_post");
        const modal = document.getElementById("myModal");
        if (feedPost) {
          const post = {
            _id: feedPost.dataset.postId,
            title: feedPost.dataset.title,
            imageUrl: feedPost.dataset.imageUrl,
            description: feedPost.dataset.description,
            likes: feedPost.dataset.likes,
            owner: feedPost.dataset.owner,
          };
          fillModal(post);
          modal.style.display = "block";
        }
      });
    })
    .catch((error) => console.error("Error fetching posts:", error));
}

async function fillModal(post) {
  const modal = document.getElementById("myModal");
  const modalTitle = modal.querySelector("h2");
  const modalImage = modal.querySelector(".enlarged_left img");
  const modalDescription = modal.querySelector(".enlarged_left p");
  const likesHeart = document.getElementById("likes_heart");
  const likesCount = modal.querySelector(".likes_count");

  modalTitle.textContent = post.title;
  modalImage.src = post.imageUrl;
  modalDescription.textContent = post.description;
  likesCount.textContent = post.likes;
  likesHeart.style.color = "white";

  // Get the <span> element that closes the modal
  var span = modal.querySelector(".close");

  // When the user clicks on <span> (x), close the modal
  span.onclick = function () {
    modal.style.display = "none";
  };

  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function (event) {
    if (event.target == modal) {
      modal.style.display = "none";
    }
  };

  likesHeart.onclick = async () => {
    try {
      const response = await fetch(
        `http://localhost:8080/m00909449/like/${post._id}`,
        {
          method: "POST",
        }
      );

      // Output result
      const result = await response.json();
      console.log("Likes updated successfully!");
      console.log(result);
      likesCount.textContent = Number(post.likes) + 1;
      likesHeart.style.color = "red";
      fillMain();
    } catch (err) {
      console.log("Error adding like: " + err);
    }
  };

  modal.style.display = "block";
  await fetchComments(post._id);

  // Add event listener for the comment form submission
  const sendComment = modal.querySelector(".send_comment");
  sendComment.onclick = async (event) => {
    // Get the comment text
    const commentInput = document.querySelector(".give_comment");
    const commentText = commentInput.value;

    // Call the addComments function with the post ID and comment text
    await addComments(post._id, commentText);

    // Clear the comment input
    commentInput.value = "";

    // Refresh the comments section
    await fetchComments(post._id);
  };
}

async function fetchComments(postId) {
  try {
    const response = await fetch(`/m00909449/comments/${postId}`);
    const comments = await response.json();
    console.log(comments);
    const commentsDiv = document.querySelector(".comments");

    // Clear existing comments
    commentsDiv.innerHTML = "";

    comments.forEach((comment) => {
      const commentDiv = document.createElement("div");
      commentDiv.classList.add("single_comment");

      const image = document.createElement("img");
      image.src = comment.profileImage;
      image.alt = "";
      image.id = "profile_post_image";

      const innerDiv = document.createElement("div");
      const username = document.createElement("p");
      const commentDescription = document.createElement("p");

      username.classList.add("commenter");
      username.textContent = comment.username;

      commentDescription.classList.add("comment_description");
      commentDescription.textContent = comment.comment;

      innerDiv.appendChild(username);
      innerDiv.appendChild(commentDescription);
      commentDiv.appendChild(image);
      commentDiv.appendChild(innerDiv);
      commentsDiv.appendChild(commentDiv);
    });
  } catch (error) {
    console.error("Error fetching post's comments");
  }
}

async function addComments(postId, commentText) {
  if (commentText.length === 0) {
    return;
  }
  const body = {
    postID: postId,
    comment: commentText,
  };

  try {
    const response = await fetch("http://localhost:8080/m00909449/comments", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    });

    // Output result
    const result = await response.json();
    console.log("Comment added successfully!");
    console.log(result);
  } catch (err) {
    console.log("Error adding comment: " + err);
  }
}

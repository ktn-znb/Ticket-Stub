import { app } from "../server.js";

//Set up Chai library
import chai from "chai";
let should = chai.should();
let assert = chai.assert;
let expect = chai.expect;

//Set up Chai for testing web service
import chaiHttp from "chai-http";
chai.use(chaiHttp);

describe("Web Service", () => {
  //Test of GET request sent to /users
  describe("/GET Posts Of loggedIn User", () => {
    it("should GET all the posts of loggedIn User", (done) => {
      chai
        .request(app)
        .get("/m00909449/myPosts")
        .end((err, response) => {
          //Check there are no errors
          expect(err).to.equal(null);

          //Check the status code
          response.should.have.status(200);

          //Convert returned JSON to JavaScript object
          let responseObject = JSON.parse(response.text);

          //Check that an array of posts is returned
          responseObject.should.be.a("array");

          //Check that appropriate properties are returned
          if (responseObject.length > 1) {
            responseObject[0].should.have.property("title");
            responseObject[0].should.have.property("description");
            responseObject[0].should.have.property("filename");
          }

          done();
        });
    });
  });
});

describe("Web Service", () => {
  //Test of GET request sent to /comments/:postID
  describe("/GET comments of a particular post", () => {
    it("should GET all comments of a particular post", (done) => {
      chai
        .request(app)
        .get("/m00909449/comments/6620cf94965a7a9e30e18321")
        .end((err, response) => {
          //Check there are no errors
          expect(err).to.equal(null);

          //Check the status code
          response.should.have.status(200);

          //Convert returned JSON to JavaScript object
          let responseObject = JSON.parse(response.text);

          //Check that an array of posts is returned
          responseObject.should.be.a("array");

          //Check that appropriate properties are returned
          if (responseObject.length > 1) {
            responseObject[0].should.have.property("username");
            responseObject[0].should.have.property("profileImage");
            responseObject[0].should.have.property("postID");
            responseObject[0].should.have.property("comment");
          }

          done();
        });
    });
  });
});

describe("Web Service", () => {
  describe("/GET posts of user that he/she is following", () => {
    it("should GET all posts of user that he/she is following", (done) => {
      chai
        .request(app)
        .get("/m00909449/posts/following")
        .end((err, response) => {
          //Check there are no errors
          expect(err).to.equal(null);

          //Check the status code
          response.should.have.status(200);

          //Convert returned JSON to JavaScript object
          let responseObject = JSON.parse(response.text);

          //Check that an array of posts is returned
          responseObject.should.be.a("array");

          //Check that appropriate properties are returned
          if (responseObject.length > 1) {
            responseObject[0].should.have.property("username");
            responseObject[0].should.have.property("profileImage");
            responseObject[0].should.have.property("postID");
            responseObject[0].should.have.property("comment");
          }

          done();
        });
    });
  });
});

const newComment = {
  username: "zainabK",
  profileImage: "./uploads/flower.jpg",
  postID: "094845y73428780934234",
  comment: "Really nice observation!",
};

describe("Web Service", () => {
  describe("/GET posts of user that he/she is following", () => {
    it("should GET all posts of user that he/she is following", (done) => {
      chai
        .request(app)
        .post("/m00909449/comments")
        .end((err, response) => {
          //Check there are no errors
          expect(err).to.equal(null);

          //Check the status code
          response.should.have.status(200);

          //Convert returned JSON to JavaScript object
          let responseObject = JSON.parse(response.text);

          //Check that an array of posts is returned
          responseObject.should.be.a("object");

          //Check that appropriate properties are returned
          expect(responseObject).to.deep.equal({
            message: "Comment added successfully",
            comment: newComment,
          });

          done();
        });
    });
  });
});

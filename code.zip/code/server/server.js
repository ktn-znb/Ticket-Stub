import express from "express";
import bodyParser from "body-parser";
import cors from "cors";
import expressSession from "express-session";
import fileUpload from "express-fileupload";
import { MongoClient, ObjectId, ServerApiVersion } from "mongodb";
import path from "path";
import { fileURLToPath } from "url";
import { dirname } from "path";
import ConnectMongoDBSession from "connect-mongodb-session";

export const app = express();

const MongoDBStore = ConnectMongoDBSession(expressSession);

const store = new MongoDBStore({
  uri: "mongodb://127.0.0.1:27017/TicketStub",
  collection: "Sessions",
});

app.use(
  expressSession({
    secret: "ChinguShenangigans",
    cookie: { maxAge: 10 * 24 * 60 * 60 * 1000 },
    resave: false,
    saveUninitialized: true,
    store: store,
  })
);

//setting up the paths to get the index.html
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

app.use(express.static(path.join(__dirname, "client")));
app.use(fileUpload());
app.use(express.json());
app.use(cors({ credentials: true, origin: true }));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

//Create connection url for root and no password
const connectionURL = "mongodb://127.0.0.1:27017?retryWrites=true&w=majority";
//Set up client
const client = new MongoClient(connectionURL, {
  serverApi: {
    version: ServerApiVersion.v1,
    strict: false,
    deprecationErrors: true,
  },
});

//Use client to create database and collection
const database = client.db("TicketStub");
const User = database.collection("User");
const Post = database.collection("Posts");
const Comments = database.collection("Comments");

// Define the path to the public directory
const publicPath = path.join(__dirname, "..", "client"); // Assuming the server.js is located in the server directory

// Serve static files from the public directory
app.use(express.static(publicPath));

// Route to serve the index.html file
app.get("/", async (req, res) => {
  res.sendFile(path.join(publicPath, "index.html"));
});

//route to register a user - works
app.post("/m00909449/ticket", register);
//route to login a user
app.post("/m00909449/login", login);
//create a new post
app.post("/m00909449/post", addPost);
//follow user and show up in their following
app.post("/m00909449/follow", followUser);
//post comments for a particular posts
app.post("/m00909449/comments", addComments);
// add like to a particular post
app.post("/m00909449/like/:postID", addLikeToPost);

//route to logout a user
app.get("/m00909449/logout", logout);
//route to check if the user is logged in
app.get("/m00909449/checklogin", checklogin);
// get the current user
app.get("/m00909449/currentUser", getCurrentUser);
//get all users - works
app.get("/m00909449/users", getUsers);
//get all posts of logged in user
app.get("/m00909449/myPosts", getMyPosts);
//get all posts of followed users
app.get("/m00909449/posts/following", getPostsOfFollowedUsers);
//get all posts of a particular user
app.get("/m00909449/posts/:userID", getPostsOfUser);
// get all comments of a particular post
app.get("/m00909449/comments/:postID", getCommentsOfPost);

// Serve static files from the 'uploads' directory
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

//function to register a user
async function register(request, response) {
  if (!request.files || Object.keys(request.files).length === 0) {
    return response.status(400).json({ upload: false, error: "Files missing" });
  }

  let myFile = request.files.profileImage;
  let firstName = request.body.firstName;
  let lastName = request.body.lastName;
  let username = request.body.username;
  let age = request.body.age;
  let password = request.body.password;
  let retypePassword = request.body.retypePassword;
  let email = request.body.email;
  let followers = request.body.followers;
  let following = request.body.following;
  let posts = request.body.posts;

  myFile.mv("./uploads/" + myFile.name, async function (err) {
    if (err)
      return response
        .status(500)
        .json({ filename: myFile.name, upload: false, error: err });

    // Define newUser object with user data
    const newUser = {
      firstName: firstName,
      lastName: lastName,
      username: username,
      age: age,
      password: password,
      retypePassword: retypePassword,
      email: email,
      profileImageUrl: "http://localhost:8080/uploads/" + myFile.name,
      followers: [],
      following: [],
      posts: posts,
    };

    try {
      // Run query and output result
      const result = await User.insertOne(newUser);
      console.log(result);

      // Send back confirmation of the upload to the client, including the name and age
      response.json({
        filename: myFile.name,
        username: username,
        firstName: firstName,
        lastName: lastName,
        password: password,
        retypePassword: retypePassword,
        email: email,
        age: age,
        upload: true,
      });
    } catch (err) {
      console.error(err);
      response.status(500).json(err);
    }
  });
}

//function to login a user
async function login(request, response) {
  try {
    const { username, password } = request.body;

    // Find user in MongoDB based on username
    const user = await User.findOne({ username });

    if (!user) {
      response
        .status(401)
        .json({ login: false, message: "Username or password incorrect." });
      return;
    }

    // Check if password matches
    const passwordMatch = password === user.password;

    if (!passwordMatch) {
      response
        .status(401)
        .json({ login: false, message: "Username or password incorrect." });
      return;
    }

    // Store username in session
    request.session.username = user.username;
    request.session.userID = user._id;
    request.session.userProfileImage = user.profileImageUrl;
    request.session.save();
    response.json({ login: true, user: request.session.username });
  } catch (error) {
    console.error("Error logging in:", error);
    response.status(500).json({ message: "Internal server error" });
  }
}

//function to logut a user
function logout(request, response) {
  //Destroy session.
  request.session.destroy((err) => {
    if (err) response.send('{"error": ' + JSON.stringify(err) + "}");
    else response.send('{"login":false}');
  });
}

// fucntion to check login
function checklogin(request, response) {
  console.log("Session ID in checklogin:", request.sessionID);
  if (request.session.username) {
    response.json({ login: true, username: request.session.username });
  } else {
    response.json({ login: false });
  }
}

//function to get current user
async function getCurrentUser(request, response) {
  try {
    const username = request.session.username;
    const user = await User.findOne({ username });

    if (!user) {
      response.status(404).json({ message: "User not found" });
      return;
    }

    response.json(user);
  } catch (error) {
    console.error("Error fetching current user:", error);
    response.status(500).json({ message: "Internal server error" });
  }
}

//function to get all the user
async function getUsers(request, response) {
  try {
    const usersCursor = User.find({}); // Find all users
    const usersArray = await usersCursor.toArray(); // Convert cursor to array
    console.log("Fetched users:", usersArray);
    response.json(usersArray); // Send the users as JSON response
  } catch (error) {
    console.error("Error fetching users:", error);
    response.status(500).json({ message: "Internal server error" });
  }
}

// function to create a new post
async function addPost(request, response) {
  if (
    !request.files ||
    Object.keys(request.files).length === 0 ||
    !request.files.imageFile
  ) {
    return response
      .status(400)
      .json({ upload: false, error: "Image file is missing" });
  }

  let imageFile = request.files.imageFile;
  let title = request.body.title;
  let description = request.body.description;

  // Move the uploaded file to the 'uploads' folder
  const uploadPath = path.join(__dirname, "uploads", imageFile.name);
  imageFile.mv(uploadPath, async function (err) {
    if (err) {
      return response
        .status(500)
        .json({ filename: imageFile.name, upload: false, error: err });
    }

    // Get the current user
    const username = request.session.username;
    const user = await User.findOne({ username });

    if (!user) {
      return response.status(404).json({ message: "User not found" });
    }

    // Parse the 'posts' field from string to integer
    const posts = parseInt(user.posts, 10);

    // Define newPost object with post data and owner
    const newPost = {
      title: title,
      description: description,
      imageUrl: "http://localhost:8080/uploads/" + imageFile.name,
      owner: user._id,
      likes: 0, // Initial value for likes
    };

    try {
      // Insert the new post into the database
      await Post.insertOne(newPost);

      // Update the user's posts count
      await User.updateOne(
        { _id: user._id },
        { $set: { posts: posts + 1 } } // Increment posts count by 1
      );

      // Send back confirmation of the upload to the client
      response.json({
        filename: imageFile.name,
        title: title,
        description: description,
        upload: true,
      });
    } catch (err) {
      console.error(err);
      response.status(500).json(err);
    }
  });
}

//funtion to get all posts of logged in user
async function getMyPosts(request, response) {
  try {
    const id = request.session.userID;
    const posts = Post.find({ owner: new ObjectId(id) });
    const postsArray = await posts.toArray();
    response.json(postsArray);
  } catch (error) {
    console.error("Error fetching users:", error);
    response.status(500).json({ message: "Internal server error" });
  }
}

//funtion to get all posts of a particular user
async function getPostsOfUser(request, response) {
  try {
    const { userID } = request.params;
    const posts = Post.find({ owner: new ObjectId(userID) });
    const postsArray = await posts.toArray();
    response.json(postsArray);
  } catch (error) {
    console.error("Error fetching users:", error);
    response.status(500).json({ message: "Internal server error" });
  }
}

//function to follow and get followed
async function followUser(request, response) {
  try {
    const { followID, followUsername } = request.body;
    const sessionUserID = request.session.userID;
    const sessionUser = request.session.username;

    // Update following of current user
    await User.findOneAndUpdate(
      { _id: sessionUserID },
      {
        $addToSet: {
          following: {
            _id: new ObjectId(followID),
            username: followUsername,
          },
        },
      }
    );

    // Update followers of clicked user
    const result = await User.findOneAndUpdate(
      { _id: new ObjectId(followID) },
      {
        $addToSet: {
          followers: { _id: sessionUserID, username: sessionUser },
        },
      }
    );

    console.log("Update result:", result);

    response.status(200).json({ message: "User followed successfully" });
  } catch (error) {
    console.error("Error following user:", error);
    response.status(500).send("Failed to follow user");
  }
}

//function to get all posts of users that the current user is following
async function getPostsOfFollowedUsers(request, response) {
  try {
    const userID = request.session.userID;
    const user = await User.findOne({ _id: userID });
    const followingIDs = user.following.map((user) => user._id);
    const postQueries = followingIDs.map((followingID) =>
      Post.find({ owner: followingID }).toArray()
    );

    const posts = await Promise.all(postQueries);
    const allPosts = posts.reduce((all, current) => all.concat(current), []);
    response.json(allPosts);
  } catch (error) {
    console.error("Error fetching posts of followed users:", error);
    response.status(500).json({ message: "Internal server error" });
  }
}

//function to post a comment
async function addComments(request, response) {
  try {
    // Extract comment data from the request
    const { postID, comment } = request.body;

    // Get the current user's details from the session
    const username = request.session.username;

    const userProfileImage = request.session.userProfileImage;

    // Create a new comment object
    const newComment = {
      username: username,
      profileImage: userProfileImage,
      postID: new ObjectId(postID),
      comment: comment,
    };

    // Insert the new comment into the Comments collection
    await Comments.insertOne(newComment);

    // Send back confirmation of the comment to the client
    response.json({
      message: "Comment added successfully",
      comment: newComment,
    });
  } catch (err) {
    console.error(err);
    response.status(500).json({ error: "Failed to add comment" });
  }
}

// function to get all comments of a post
async function getCommentsOfPost(request, response) {
  try {
    const { postID } = request.params;
    const comments = Comments.find({ postID: new ObjectId(postID) });
    const commentsArray = await comments.toArray();
    response.json(commentsArray);
  } catch (error) {
    console.error(err);
    response.status(500).json({ error: "Failed to load comments" });
  }
}

async function addLikeToPost(request, response) {
  try {
    const { postID } = request.params;
    const updatedPost = await Post.findOneAndUpdate(
      { _id: new ObjectId(postID) },
      { $inc: { likes: 1 } },
      { new: true }
    );
    if (!updatedPost) {
      return res.status(404).json({ message: "Post not found" });
    }
    console.log(updatedPost);
    response.json(updatedPost);
  } catch (error) {
    console.error(err);
    response.status(500).json({ error: "Failed to load comments" });
  }
}

app.listen(8080);
console.log("Listening on 8080....");
